package com.lesson8.sqlite.adapter;

import android.view.View;

public interface ItemListener {
    void onItemClick(View view, int position);
}
