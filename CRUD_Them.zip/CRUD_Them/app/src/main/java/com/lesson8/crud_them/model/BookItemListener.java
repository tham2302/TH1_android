package com.lesson8.crud_them.model;

import android.view.View;

public interface BookItemListener {
    void onItemClick(View view, int position);
}
