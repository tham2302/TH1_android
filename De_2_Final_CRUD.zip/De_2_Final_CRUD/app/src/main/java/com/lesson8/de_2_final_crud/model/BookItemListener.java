package com.lesson8.de_2_final_crud.model;

import android.view.View;

public interface BookItemListener {
    void onItemClick(View view, int position);
}
