package com.lesson8.crud.model;

import android.view.View;

public interface CatItemListener {
    void onItemClick(View view, int position);
}
