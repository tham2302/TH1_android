package com.lesson8.de1_crud.model;

import android.view.View;

public interface BookItemListener {
    void onItemClick(View view, int position);
}
